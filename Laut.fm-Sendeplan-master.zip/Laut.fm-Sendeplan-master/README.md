# Laut.fm-Sendeplan
Dies ist eine Modifizierte Version von dem Laut.FM Sendeplan welcher durch Fabians-Welt erstellt und zur Vefügung gestellt wurde.
Bei diesem Sendeplan muss nur der Stationsname ausgetauscht werden und bei bedarf die Stylesheetdatei angepasst werden.
Die Stylesheet-Datei kann wie folgt eingebunden werden
